import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-950 border-t border-white/5 py-16 relative overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[1px] bg-gradient-to-r from-transparent via-purple-500 to-transparent opacity-50"></div>
        
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center md:text-right">
          <div>
            <div className="flex items-center justify-center md:justify-start mb-6">
                 <span className="text-2xl">🌙</span>
                 <h3 className="text-2xl font-black text-white mr-2 tracking-tight">LUNA<span className="text-purple-500">CRAFT</span></h3>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed mb-6">
              لونا کرافت، فراتر از یک سرور ماینکرفت. ما جامعه‌ای هستیم که در آن خلاقیت مرزی ندارد. با بهترین پینگ و پشتیبانی ۲۴ ساعته.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-bold text-white mb-6 border-b border-white/10 pb-2 inline-block">لینک‌های دسترسی</h3>
            <ul className="space-y-3 text-sm text-slate-400">
              <li><a href="#" className="hover:text-purple-400 transition-colors flex items-center justify-center md:justify-start gap-2"><span className="text-purple-600">›</span> قوانین سرور</a></li>
              <li><a href="#" className="hover:text-purple-400 transition-colors flex items-center justify-center md:justify-start gap-2"><span className="text-purple-600">›</span> فروشگاه آنلاین</a></li>
              <li><a href="#" className="hover:text-purple-400 transition-colors flex items-center justify-center md:justify-start gap-2"><span className="text-purple-600">›</span> درخواست همکاری</a></li>
              <li><a href="#" className="hover:text-purple-400 transition-colors flex items-center justify-center md:justify-start gap-2"><span className="text-purple-600">›</span> ویکی لونا</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold text-white mb-6 border-b border-white/10 pb-2 inline-block">جامعه ما</h3>
            <div className="flex justify-center md:justify-start space-x-4 space-x-reverse">
               <a href="#" className="group w-12 h-12 rounded-2xl bg-slate-900 border border-white/5 flex items-center justify-center text-slate-400 hover:bg-[#5865F2] hover:text-white hover:border-[#5865F2] hover:-translate-y-1 transition-all duration-300">
                 <span className="font-bold text-xs">DIS</span>
               </a>
               <a href="#" className="group w-12 h-12 rounded-2xl bg-slate-900 border border-white/5 flex items-center justify-center text-slate-400 hover:bg-[#229ED9] hover:text-white hover:border-[#229ED9] hover:-translate-y-1 transition-all duration-300">
                  <span className="font-bold text-xs">TG</span>
               </a>
               <a href="#" className="group w-12 h-12 rounded-2xl bg-slate-900 border border-white/5 flex items-center justify-center text-slate-400 hover:bg-[#E1306C] hover:text-white hover:border-[#E1306C] hover:-translate-y-1 transition-all duration-300">
                  <span className="font-bold text-xs">IG</span>
               </a>
            </div>
          </div>
        </div>
        
        <div className="mt-16 pt-8 border-t border-white/5 text-center flex flex-col md:flex-row justify-between items-center text-slate-500 text-xs gap-4">
          <p>&copy; 2024 LunaCraft Network. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <span className="w-1 h-1 bg-slate-700 rounded-full"></span>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
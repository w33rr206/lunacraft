import React from 'react';
import { GAME_MODES } from '../constants';

const GameModes: React.FC = () => {
  return (
    <section id="gamemodes" className="py-24 bg-slate-950 relative overflow-hidden">
      {/* Background glow effects */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 -right-64 w-96 h-96 bg-purple-600/20 rounded-full blur-[100px]"></div>
        <div className="absolute bottom-1/4 -left-64 w-96 h-96 bg-pink-600/10 rounded-full blur-[100px]"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20">
          <span className="text-purple-400 font-bold tracking-wider text-sm uppercase mb-2 block">دنیای خود را انتخاب کنید</span>
          <h2 className="text-4xl md:text-5xl font-black text-white mb-6">
            گیم‌مودهای <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500">لونا کرافت</span>
          </h2>
          <p className="text-slate-400 max-w-2xl mx-auto text-lg">
            هر گیم‌مود یک سیاره جدید برای کشف کردن است. آماده‌اید؟
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {GAME_MODES.map((mode) => (
            <div 
              key={mode.id} 
              className="group relative bg-slate-900/50 backdrop-blur-sm rounded-3xl overflow-hidden border border-white/5 hover:border-purple-500/50 transition-all duration-500 hover:shadow-[0_0_40px_rgba(147,51,234,0.15)] hover:-translate-y-2"
            >
              <div className="relative h-56 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 to-transparent z-10"></div>
                <img 
                  src={mode.image} 
                  alt={mode.title} 
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute top-4 right-4 z-20">
                   <span className="px-3 py-1 bg-black/50 backdrop-blur-md rounded-full text-xs font-bold text-white border border-white/10 flex items-center gap-2">
                     <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse shadow-[0_0_10px_#22c55e]"></span>
                     {mode.playerCount} آنلاین
                   </span>
                </div>
              </div>
              
              <div className="p-8 relative z-20 -mt-12">
                <div className="bg-slate-800/80 backdrop-blur-xl p-6 rounded-2xl border border-white/5 group-hover:border-purple-500/30 transition-colors">
                    <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-purple-400 transition-colors">
                    {mode.title}
                    </h3>
                    <p className="text-slate-400 text-sm leading-relaxed mb-6">
                    {mode.description}
                    </p>
                    <button className="w-full py-3 bg-gradient-to-r from-slate-700 to-slate-800 hover:from-purple-600 hover:to-pink-600 text-white rounded-xl transition-all font-bold text-sm shadow-lg group-hover:shadow-purple-500/25">
                    شروع بازی
                    </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default GameModes;
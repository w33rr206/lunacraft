import React, { useState } from 'react';
import { SERVER_IP } from '../constants';

const Hero: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const copyIp = () => {
    navigator.clipboard.writeText(SERVER_IP);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div id="home" className="relative h-screen flex items-center justify-center overflow-hidden bg-slate-950">
      {/* Dynamic Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-900/40 via-slate-950 to-slate-950"></div>
        <img 
          src="https://picsum.photos/1920/1080?grayscale&blur=4" 
          alt="Moon Landscape" 
          className="w-full h-full object-cover opacity-20 mix-blend-overlay"
        />
        {/* Animated stars/particles simulation */}
        <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-white rounded-full animate-ping opacity-75"></div>
        <div className="absolute top-1/3 right-1/4 w-1 h-1 bg-purple-400 rounded-full animate-pulse"></div>
        <div className="absolute bottom-1/4 left-1/3 w-3 h-3 bg-pink-500/50 rounded-full blur-md animate-bounce" style={{animationDuration: '3s'}}></div>
      </div>

      <div className="relative z-10 text-center px-4 max-w-5xl mx-auto mt-16">
        <div className="inline-block animate-bounce mb-4">
           <span className="px-4 py-1.5 rounded-full border border-purple-500/30 bg-purple-500/10 text-purple-300 text-xs font-bold tracking-widest uppercase backdrop-blur-md">
             Season 5 is Live 🚀
           </span>
        </div>
        
        <h1 className="text-6xl md:text-8xl font-black text-white mb-6 tracking-tight drop-shadow-2xl">
          <span className="text-transparent bg-clip-text bg-gradient-to-b from-white to-slate-400">LUNA</span>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-500 via-fuchsia-500 to-pink-500 text-glow">CRAFT</span>
        </h1>
        
        <p className="text-lg md:text-2xl text-slate-300 mb-10 max-w-2xl mx-auto font-light leading-relaxed">
          سفری به اعماق کهکشان ماینکرفت. جایی که رویاها ساخته می‌شوند و افسانه‌ها زنده می‌مانند.
        </p>
        
        <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
          <button 
            onClick={copyIp}
            className="group relative inline-flex items-center justify-center px-8 py-4 text-lg font-bold text-white transition-all duration-200 bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-600 hover:shadow-[0_0_30px_rgba(168,85,247,0.5)] hover:scale-105 active:scale-95 ring-offset-slate-900"
          >
            {copied ? (
              <span className="flex items-center">
                <svg className="w-6 h-6 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
                کپی شد!
              </span>
            ) : (
              <span className="flex items-center">
                <svg className="w-6 h-6 ml-2 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3"></path></svg>
                {SERVER_IP}
              </span>
            )}
          </button>
          
          <a href="#gamemodes" className="px-8 py-4 text-lg font-bold text-white transition-all duration-200 bg-white/5 border border-white/10 backdrop-blur-sm rounded-2xl hover:bg-white/10 hover:border-purple-500/50 hover:shadow-[0_0_20px_rgba(168,85,247,0.2)]">
            کاوش در سرور
          </a>
        </div>

        {/* Stats */}
        <div className="mt-16 grid grid-cols-3 gap-8 max-w-3xl mx-auto border-t border-white/5 pt-8">
          <div className="flex flex-col items-center group">
            <span className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-br from-yellow-300 to-orange-500 mb-1 group-hover:scale-110 transition-transform">450+</span>
            <span className="text-slate-400 text-sm">پلیر آنلاین</span>
          </div>
          <div className="flex flex-col items-center group border-x border-white/5">
            <span className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-br from-cyan-300 to-blue-500 mb-1 group-hover:scale-110 transition-transform">12ms</span>
            <span className="text-slate-400 text-sm">پینگ ایران</span>
          </div>
          <div className="flex flex-col items-center group">
            <span className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-br from-green-300 to-emerald-500 mb-1 group-hover:scale-110 transition-transform">24/7</span>
            <span className="text-slate-400 text-sm">همیشه آنلاین</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
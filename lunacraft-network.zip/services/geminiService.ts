import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `
You are 'LunaBot', a mystical and helpful assistant for the 'LunaCraft' Minecraft server.
Your primary language is Persian (Farsi).
You help players with:
1. Server IP: play.lunacraft.ir
2. Game modes: Survival, Bedwars, Skyblock (themed around moon/space).
3. Troubleshooting connection issues.
4. Explaining basic Minecraft mechanics.

Tone: Magical, welcoming, slightly mysterious but very helpful.
Use emojis like: 🌙, ✨, 🚀, 💎, 💜.
If asked about something unrelated to Minecraft or the server, politely steer the conversation back to the game.
Always reply in Persian.
`;

export const sendMessageToGemini = async (message: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: message,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      },
    });

    return response.text || "ارتباط با ماه قطع شده است...";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "در حال حاضر قادر به پاسخگویی نیستم. لطفا بعدا تلاش کنید.";
  }
};